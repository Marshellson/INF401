/* prog.c */

int NN = 0xffff;
char CC[8] = "charlot";

int main() {
    NN = 333;
    NN = NN + 5;
  return 0;
}
